from django.db import models

class Products(models.Model):
    Title       = models.CharField(max_length=200)
    Description = models.TextField()
    Material_Choice=[('S','Silk'),
    ('C','Cotton')
    ]
    Clothe_Choice=[('SA','Saree'),
    ('KU','Kurta'),
    ('DU','Dupatha'),
]
    Material    = models.CharField(max_length = 100, choices = Material_Choice, default = 'C')
    Clothe_Type = models.CharField(max_length = 100, choices = Clothe_Choice, default = 'SA')
    Price       = models.DecimalField(max_digits = 100 ,decimal_places = 2, )
    Offer       = models.BooleanField(default=False)
    Image       = models.ImageField(upload_to='pics')
    





